# CORONA-Net
Source code for the paper: CORONA-Net: COnvolutional Re-initialization Optimization Network for Detecting  COVID-19 from CT and X-ray images

## download the pr-trained weights
You can download the pre-trained weights from  [here](https://github.com/Abdelpakey/CORONA-Net)

After you downlad the pretrained weights, put the .pth file in te model folder.

## Dataset

To  download and curate the dataset, plese refer to this [link](https://github.com/lindawangg/COVID-Net/blob/master/create_COVIDx.ipynb)
